<?php

/**
 * Router Class
 * Handles HTTP routing for the MVC application
 * 
 * @author Robert Miras 2025
 */

namespace app;

class Router
{

	public array $getRoutes = [];
	public array $postRoutes = [];

	public function get($url, $fn) 
	{
	  $this->getRoutes[$url] = $fn;
	}

	public function post($url, $fn) 
	{
		$this->postRoutes[$url] = $fn;
	}

	public function resolve() 
	{
		// Better URL handling for shared hosting
		$currentUrl = $this->getCurrentUrl();
		$http_method = $_SERVER['REQUEST_METHOD'];

		if ($http_method == 'GET') {
			$fn = $this->getRoutes[$currentUrl] ?? null;
		} else {
			$fn = $this->postRoutes[$currentUrl] ?? null;
		}

		if($fn) {
			// Check if it's an array (controller, method)
			if (is_array($fn)) {
				$controller = new $fn[0]();
				$method = $fn[1];
				call_user_func([$controller, $method], $this);
			} else {
				// Execute the function
				call_user_func($fn, $this);
			}
		} else {
			echo 'Page Not Found';
 		}		

	}

	private function getCurrentUrl()
	{
		// Multiple fallback methods for shared hosting compatibility
		$url = '/';
		
		// Method 1: PATH_INFO (works on local development)
		if (isset($_SERVER['PATH_INFO']) && !empty($_SERVER['PATH_INFO'])) {
			$url = $_SERVER['PATH_INFO'];
		}
		// Method 2: REQUEST_URI parsing (works on most shared hosting)
		elseif (isset($_SERVER['REQUEST_URI'])) {
			$requestUri = $_SERVER['REQUEST_URI'];
			// Remove query string
			$requestUri = strtok($requestUri, '?');
			// Remove script name if present
			$scriptName = $_SERVER['SCRIPT_NAME'];
			$scriptDir = dirname($scriptName);
			
			if ($scriptDir !== '/' && strpos($requestUri, $scriptDir) === 0) {
				$url = substr($requestUri, strlen($scriptDir));
			} else {
				$url = $requestUri;
			}
			
			// Ensure URL starts with /
			if (substr($url, 0, 1) !== '/') {
				$url = '/' . $url;
			}
		}
		// Method 3: Query parameter fallback
		elseif (isset($_GET['url'])) {
			$url = '/' . trim($_GET['url'], '/');
		}
		
		return $url ?: '/';
	}

	public function renderView($viewPath, $params = []) 
	{	
		// This will pass param data in views
		foreach ($params as $key => $value) {
			$$key = $value;
		}

	   // Render views
	   include_once __DIR__.'/views/'.$viewPath.'.php';
	}
}
