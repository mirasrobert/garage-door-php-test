<?php

/**
 * CheckoutController
 * Handles the multi-step checkout process for garage door services
 * 
 * @author Robert Miras 2025
 */

namespace app\controllers;

use app\models\CustomerDetails;
use app\models\PaymentDetails;
use app\Router;

class CheckoutController
{
    public function __construct()
    {
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function step1(Router $router)
    {
        $errors = $_SESSION['errors'] ?? [];
        unset($_SESSION['errors']);
        
        return $router->renderView('checkout/step1', [
            'customer' => $_SESSION['customer'] ?? [],
            'errors' => $errors
        ]);
    }

    public function processStep1(Router $router)
    {
        $errors = [];
        $customer = [];

        // Validate required fields
        $requiredFields = [
            'first_name' => 'First Name',
            'last_name' => 'Last Name', 
            'address' => 'Address',
            'city' => 'City',
            'state' => 'State',
            'phone' => 'Phone',
            'email' => 'Email'
        ];

        foreach ($requiredFields as $field => $label) {
            $value = trim($_POST[$field] ?? '');
            if (empty($value)) {
                $errors[$field] = $label . ' is required';
            } else {
                $customer[$field] = $value;
            }
        }

        // Additional validation
        if (!empty($customer['email']) && !filter_var($customer['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Please enter a valid email address';
        }

        if (!empty($customer['phone']) && !preg_match('/^\d{10}$/', preg_replace('/\D/', '', $customer['phone']))) {
            $errors['phone'] = 'Please enter a valid 10-digit phone number';
        }

        if (!empty($customer['state']) && strlen($customer['state']) !== 2) {
            $errors['state'] = 'State must be 2 characters (e.g., MA)';
        }

        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['customer'] = $customer;
            header('Location: /checkout/step1');
            exit;
        }

        // Clean phone number
        $customer['phone'] = preg_replace('/\D/', '', $customer['phone']);
        
        $_SESSION['customer'] = $customer;
        header('Location: /checkout/step2');
        exit;
    }

    public function step2(Router $router)
    {
        // Check if step 1 is completed
        if (empty($_SESSION['customer'])) {
            header('Location: /checkout/step1');
            exit;
        }

        $errors = $_SESSION['errors'] ?? [];
        unset($_SESSION['errors']);

        return $router->renderView('checkout/step2', [
            'payment' => $_SESSION['payment'] ?? [],
            'errors' => $errors
        ]);
    }

    public function processStep2(Router $router)
    {
        if (empty($_SESSION['customer'])) {
            header('Location: /checkout/step1');
            exit;
        }

        $errors = [];
        $payment = [];

        // Validate required fields
        $requiredFields = [
            'card_type' => 'Card Type',
            'card_number' => 'Card Number',
            'card_exp_date' => 'Expiration Date',
            'cvv' => 'CVV Code'
        ];

        foreach ($requiredFields as $field => $label) {
            $value = trim($_POST[$field] ?? '');
            if (empty($value)) {
                $errors[$field] = $label . ' is required';
            } else {
                $payment[$field] = $value;
            }
        }

        // Additional validation
        if (!empty($payment['card_number'])) {
            $cardNumber = preg_replace('/\D/', '', $payment['card_number']);
            if (strlen($cardNumber) < 13 || strlen($cardNumber) > 19) {
                $errors['card_number'] = 'Card number must be between 13 and 19 digits';
            } else {
                $payment['card_number'] = $cardNumber;
            }
        }

        if (!empty($payment['card_exp_date'])) {
            if (!preg_match('/^\d{2}\/\d{2}$/', $payment['card_exp_date'])) {
                $errors['card_exp_date'] = 'Expiration date must be in MM/YY format';
            }
        }

        if (!empty($payment['cvv'])) {
            $cvv = preg_replace('/\D/', '', $payment['cvv']);
            if (strlen($cvv) < 3 || strlen($cvv) > 4) {
                $errors['cvv'] = 'CVV must be 3 or 4 digits';
            } else {
                $payment['cvv'] = $cvv;
            }
        }

        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['payment'] = $payment;
            header('Location: /checkout/step2');
            exit;
        }

        $_SESSION['payment'] = $payment;
        header('Location: /checkout/step3');
        exit;
    }

    public function step3(Router $router)
    {
        // Check if previous steps are completed
        if (empty($_SESSION['customer']) || empty($_SESSION['payment'])) {
            header('Location: /checkout/step1');
            exit;
        }

        return $router->renderView('checkout/step3', [
            'customer' => $_SESSION['customer'],
            'payment' => $_SESSION['payment']
        ]);
    }

    public function processStep3(Router $router)
    {
        if (empty($_SESSION['customer']) || empty($_SESSION['payment'])) {
            header('Location: /checkout/step1');
            exit;
        }

        try {
            // Save customer details
            $customerId = CustomerDetails::create($_SESSION['customer']);
            
            // Save payment details (without CVV for security)
            $paymentData = $_SESSION['payment'];
            unset($paymentData['cvv']); // Don't store CVV
            $paymentId = PaymentDetails::create($paymentData);

            // Clear session data
            unset($_SESSION['customer']);
            unset($_SESSION['payment']);

            $_SESSION['success'] = 'Order completed successfully!';
            header('Location: /checkout/success?customer_id=' . $customerId . '&payment_id=' . $paymentId);
            exit;

        } catch (Exception $e) {
            $_SESSION['error'] = 'An error occurred while processing your order. Please try again.';
            header('Location: /checkout/step3');
            exit;
        }
    }

    public function success(Router $router)
    {
        $success = $_SESSION['success'] ?? '';
        $error = $_SESSION['error'] ?? '';
        unset($_SESSION['success']);
        unset($_SESSION['error']);

        return $router->renderView('checkout/success', [
            'success' => $success,
            'error' => $error,
            'customer_id' => $_GET['customer_id'] ?? '',
            'payment_id' => $_GET['payment_id'] ?? ''
        ]);
    }
} 