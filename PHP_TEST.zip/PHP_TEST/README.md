# PHP_MVC

Mass Garage Doors Expert PHP Test:

In Your Terminal:

Go to public folder:
<code>cd public</code>

Run Server:
<code>php -S localhost:8080</code>

Alternative:
Use xampp and move folder in htdocs.
The root folder is public/index.php
