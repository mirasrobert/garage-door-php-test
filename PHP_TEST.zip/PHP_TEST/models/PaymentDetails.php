<?php

/**
 * PaymentDetails Model
 * Manages payment information for checkout process
 * 
 * @author Robert Miras 2025
 */

namespace app\models;

use app\Database;

class PaymentDetails 
{
    public static function create($data) 
    {
        $db = new Database();

        $sql = 'INSERT INTO payment_details (card_type, card_number, card_exp_date) 
                VALUES (:card_type, :card_number, :card_exp_date)';
        
        $db->query($sql);
        $db->bind(':card_type', $data['card_type']);
        $db->bind(':card_number', $data['card_number']);
        $db->bind(':card_exp_date', $data['card_exp_date']);
        
        $db->execute();
        
        return $db->lastInsertId();
    }

    public static function findById($id) 
    {
        $db = new Database();

        $sql = 'SELECT * FROM payment_details WHERE id = :id';
        $db->query($sql);
        $db->bind(':id', $id);
        
        return $db->single();
    }

    public static function all() 
    {
        $db = new Database();

        $sql = 'SELECT * FROM payment_details ORDER BY id DESC';
        $db->query($sql);
        
        return $db->resultset();
    }
} 