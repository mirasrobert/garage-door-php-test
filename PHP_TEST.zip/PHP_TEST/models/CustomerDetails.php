<?php

/**
 * CustomerDetails Model
 * Manages customer information for checkout process
 * 
 * @author Robert Miras 2025
 */

namespace app\models;

use app\Database;

class CustomerDetails 
{
    public static function create($data) 
    {
        $db = new Database();

        $sql = 'INSERT INTO customer_details (first_name, last_name, address, city, state, phone, email) 
                VALUES (:first_name, :last_name, :address, :city, :state, :phone, :email)';
        
        $db->query($sql);
        $db->bind(':first_name', $data['first_name']);
        $db->bind(':last_name', $data['last_name']);
        $db->bind(':address', $data['address']);
        $db->bind(':city', $data['city']);
        $db->bind(':state', $data['state']);
        $db->bind(':phone', $data['phone']);
        $db->bind(':email', $data['email']);
        
        $db->execute();
        
        return $db->lastInsertId();
    }

    public static function findById($id) 
    {
        $db = new Database();

        $sql = 'SELECT * FROM customer_details WHERE id = :id';
        $db->query($sql);
        $db->bind(':id', $id);
        
        return $db->single();
    }

    public static function all() 
    {
        $db = new Database();

        $sql = 'SELECT * FROM customer_details ORDER BY id DESC';
        $db->query($sql);
        
        return $db->resultset();
    }
} 