<?php

/**
 * Application Entry Point
 * Main routing and application bootstrap for Mass Garage Doors Expert
 * 
 * @author Robert Miras 2025
 */

// autoload
require_once __DIR__ . '/vendor/autoload.php';

use app\Router;
use app\controllers\CheckoutController;

$router = new Router();

// Define your routes here

// Homepage and existing routes
$router->get('/', function ($router) {
    return $router->renderView('homepage');
});

// Checkout routes
$router->get('/checkout/step1', [CheckoutController::class, 'step1']);
$router->post('/checkout/step1/process', [CheckoutController::class, 'processStep1']);

$router->get('/checkout/step2', [CheckoutController::class, 'step2']);
$router->post('/checkout/step2/process', [CheckoutController::class, 'processStep2']);

$router->get('/checkout/step3', [CheckoutController::class, 'step3']);
$router->post('/checkout/step3/process', [CheckoutController::class, 'processStep3']);

$router->get('/checkout/success', [CheckoutController::class, 'success']);

// Search functionality
$router->get('/search', function ($router) {
    $query = $_GET['q'] ?? '';
    return $router->renderView('search', [
        'query' => $query,
        'results' => []
    ]);
});

$router->resolve(); 