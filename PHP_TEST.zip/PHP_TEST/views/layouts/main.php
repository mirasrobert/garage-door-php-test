<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Mass Garage Doors Expert - Checkout' ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        :root {
            --primary-yellow: #FFC600;
            --primary-black: #000000;
            --secondary-black: #1a1a1a;
            --dark-gray: #333333;
            --light-gray: #f8fafc;
            --white: #ffffff;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-gray);
            color: var(--dark-gray);
        }
        
        .header {
            background: var(--primary-black);
            color: white;
            padding: 1rem 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        
        .header h1 {
            margin: 0;
            font-weight: 700;
            font-size: 1.3rem;
            line-height: 1.2;
        }
        
        .header .tagline {
            margin: 0;
            font-size: 0.8rem;
            opacity: 0.9;
            line-height: 1.1;
        }
        
        .search-container {
            max-width: 450px;
            width: 100%;
            margin: 0 auto;
        }
        
        .header-links {
            display: flex;
            flex-direction: row;
            gap: 0.75rem;
            align-items: center;
            justify-content: center;
        }
        
        .header-link {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            transition: all 0.3s ease;
            white-space: nowrap;
        }
        
        .header-link:hover {
            color: var(--primary-black);
            background: var(--primary-yellow);
            text-decoration: none;
            transform: translateY(-1px);
        }
        
        .header-link i {
            color: inherit;
        }
        
        .search-form .input-group {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(255, 198, 0, 0.3);
        }
        
        .search-input {
            border: 2px solid #e5e7eb;
            background: white;
            color: var(--primary-black);
            padding: 0.75rem 1.25rem;
            font-size: 0.95rem;
            border-radius: 8px 0 0 8px;
            border-right: none;
        }
        
        .search-input:focus {
            border-color: var(--primary-yellow);
            box-shadow: 0 0 0 0.2rem rgba(255, 198, 0, 0.25);
            background: white;
            color: var(--primary-black);
            border-right: none;
        }
        
        .search-input::placeholder {
            color: #666;
            opacity: 0.8;
        }
        
        .search-btn {
            background: var(--primary-yellow);
            border: 2px solid var(--primary-yellow);
            color: var(--primary-black);
            padding: 0.75rem 1.25rem;
            border-radius: 0 8px 8px 0;
            transition: all 0.3s ease;
            font-weight: 600;
            border-left: none;
        }
        
        .search-btn:hover {
            background: var(--white);
            color: var(--primary-black);
            transform: scale(1.05);
        }
        
        .search-btn:focus {
            box-shadow: 0 0 0 0.2rem rgba(255, 198, 0, 0.5);
        }
        
        .checkout-container {
            max-width: 800px;
            margin: 2rem auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .progress-header {
            background: var(--primary-black);
            color: white;
            padding: 1.5rem;
        }
        
        .progress-steps {
            display: flex;
            justify-content: space-between;
            margin-top: 1rem;
        }
        
        .step {
            flex: 1;
            text-align: center;
            position: relative;
        }
        
        .step::after {
            content: '';
            position: absolute;
            top: 20px;
            right: -50%;
            width: 100%;
            height: 2px;
            background: rgba(255,255,255,0.3);
            z-index: 1;
        }
        
        .step:last-child::after {
            display: none;
        }
        
        .step-number {
            display: inline-block;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255,255,255,0.2);
            line-height: 40px;
            font-weight: bold;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 2;
        }
        
        .step.active .step-number {
            background: var(--primary-yellow);
            color: var(--primary-black);
            font-weight: bold;
        }
        
        .step.completed .step-number {
            background: #10b981;
            color: white;
        }
        
        .step.completed::after {
            background: #10b981;
        }
        
        .form-section {
            padding: 2rem;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--dark-gray);
            margin-bottom: 0.5rem;
        }
        
        .form-control {
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            padding: 0.75rem;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            border-color: var(--primary-yellow);
            box-shadow: 0 0 0 0.2rem rgba(255, 198, 0, 0.25);
        }
        
        .btn-primary {
            background: var(--primary-yellow);
            border: 2px solid var(--primary-yellow);
            color: var(--primary-black);
            padding: 0.75rem 2rem;
            font-weight: 700;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            background: var(--primary-black);
            border-color: var(--primary-yellow);
            color: var(--primary-yellow);
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: var(--primary-black);
            border: 2px solid var(--primary-black);
            color: white;
            padding: 0.75rem 2rem;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .btn-secondary:hover {
            background: transparent;
            border-color: var(--primary-black);
            color: var(--primary-black);
        }
        
        .alert {
            border: none;
            border-radius: 8px;
            padding: 1rem;
        }
        
        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border-left: 4px solid #dc2626;
        }
        
        .alert-success {
            background: #f0fdf4;
            color: #16a34a;
            border-left: 4px solid #16a34a;
        }
        
        .invalid-feedback {
            color: #dc2626;
            font-size: 0.875rem;
            margin-top: 0.25rem;
        }
        
        .footer {
            background: var(--primary-black);
            color: white;
            text-align: center;
            padding: 2rem;
            margin-top: 3rem;
        }
        
        .summary-card {
            background: var(--light-gray);
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .summary-card h5 {
            color: var(--primary-black);
            font-weight: 700;
            margin-bottom: 1rem;
        }
        
        .secondary-nav {
            background: var(--primary-yellow);
            padding: 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .nav-menu {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            padding: 0;
            list-style: none;
            flex-wrap: wrap;
        }
        
        .nav-item {
            margin: 0;
        }
        
        .nav-link {
            display: block;
            padding: 1rem 1.5rem;
            color: var(--primary-black);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
        }
        
        .nav-link:hover {
            background: var(--primary-black);
            color: var(--primary-yellow);
            border-bottom-color: var(--primary-black);
            text-decoration: none;
        }
        
        .nav-link.estimate-btn {
            background: var(--primary-black);
            color: var(--primary-yellow);
            font-weight: 700;
            margin: 0.5rem;
            border-radius: 5px;
            border-bottom: 3px solid var(--primary-black);
        }
        
        .nav-link.estimate-btn:hover {
            background: var(--white);
            color: var(--primary-black);
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }

        @media (max-width: 768px) {
            .checkout-container {
                margin: 1rem;
                border-radius: 0;
            }
            
            .progress-steps {
                flex-direction: column;
                gap: 1rem;
            }
            
            .step::after {
                display: none;
            }
            
            .nav-menu {
                flex-direction: column;
                gap: 0;
            }
            
            .nav-link {
                padding: 0.75rem 1rem;
                text-align: center;
                width: 100%;
                border-bottom: 1px solid rgba(0,0,0,0.1);
            }
            
            .nav-link.estimate-btn {
                margin: 0.5rem 1rem;
                border-radius: 5px;
                border: none;
            }
        }
        
        @media (max-width: 992px) and (min-width: 769px) {
            .nav-link {
                padding: 1rem 1rem;
                font-size: 0.9rem;
            }
        }
        
        @media (max-width: 768px) {
            .header .row {
                justify-content: center !important;
            }
            
                         .header h1 {
                 font-size: 1.2rem;
                 text-align: center;
             }
            
            .header .tagline {
                text-align: center;
                margin-bottom: 1rem;
            }
            
            .search-container {
                margin-bottom: 1rem;
            }
            
            .header-links {
                flex-direction: row;
                justify-content: center;
                flex-wrap: wrap;
                gap: 1rem;
                margin-bottom: 1rem;
            }
            
            .header-link {
                font-size: 0.85rem;
                padding: 0.5rem 0.75rem;
            }
            
            .contact-info {
                text-align: center !important;
                font-size: 0.9rem;
            }
            
            .contact-info p {
                margin-bottom: 0.25rem !important;
            }
            
            .col-lg-3 {
                display: flex;
                justify-content: center;
            }
        }
        
        @media (max-width: 992px) and (min-width: 769px) {
            .header-links {
                gap: 0.25rem;
            }
            
            .header-link {
                font-size: 0.85rem;
                padding: 0.25rem 0.4rem;
            }
        }
        
        @media (max-width: 576px) {
                         .header h1 {
                 font-size: 1.1rem;
             }
            
            .search-input {
                font-size: 0.9rem;
                padding: 0.6rem 1rem;
            }
            
            .search-btn {
                padding: 0.6rem 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-2 col-md-12">
                    <h1 style="color: var(--primary-yellow);"><i class="fas fa-home me-2" style="color: var(--primary-yellow);"></i>Mass Garage Doors Expert</h1>
                    <p class="tagline" style="color: var(--primary-yellow);">Professional Garage Door Services</p>
                </div>
                <div class="col-lg-5 col-md-8 mb-2 mb-lg-0 d-flex justify-content-center">
                    <div class="search-container">
                        <form class="search-form" action="/search" method="GET">
                            <div class="input-group">
                                <input type="text" 
                                       class="form-control search-input" 
                                       name="q" 
                                       placeholder="Search services, repairs..."
                                       aria-label="Search">
                                <button class="btn search-btn" type="submit" aria-label="Search">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-3 col-md-12 mb-2 mb-lg-0 d-flex justify-content-center">
                    <div class="header-links">
                        <a href="/expert-advice" class="header-link">
                            <i class="fas fa-user-tie me-1"></i>Expert Advice
                        </a>
                        <a href="/shop" class="header-link">
                            <i class="fas fa-shopping-cart me-1"></i>Shop
                        </a>
                        <a href="/contact" class="header-link">
                            <i class="fas fa-envelope me-1"></i>Contact Us
                        </a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 d-flex justify-content-end">
                    <div class="contact-info text-end">
                        <p class="mb-1" style="color: var(--primary-yellow);"><i class="fas fa-phone me-2"></i>(888) 989-8758</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Secondary Navigation -->
    <nav class="secondary-nav">
        <div class="container">
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="/" class="nav-link">
                        <i class="fas fa-home me-1"></i>Home
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/about" class="nav-link">
                        <i class="fas fa-users me-1"></i>About Us
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/blog" class="nav-link">
                        <i class="fas fa-blog me-1"></i>Blog
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/services" class="nav-link">
                        <i class="fas fa-tools me-1"></i>Services
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/checkout/step1" class="nav-link estimate-btn">
                        <i class="fas fa-calculator me-1"></i>Free Estimate
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/gallery" class="nav-link">
                        <i class="fas fa-images me-1"></i>Gallery
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/location" class="nav-link">
                        <i class="fas fa-map-marker-alt me-1"></i>Location
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <?= $content ?>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p class="mb-0">&copy; 2024 Mass Garage Doors Expert. All rights reserved.</p>
            <p class="mb-0">Secure SSL Checkout | Licensed & Insured</p>
        </div>
    </footer>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Auto-format phone number
        document.addEventListener('DOMContentLoaded', function() {
            const phoneInput = document.querySelector('input[name="phone"]');
            if (phoneInput) {
                phoneInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    if (value.length >= 6) {
                        value = value.substring(0,3) + '-' + value.substring(3,6) + '-' + value.substring(6,10);
                    } else if (value.length >= 3) {
                        value = value.substring(0,3) + '-' + value.substring(3);
                    }
                    e.target.value = value;
                });
            }
            
            // Auto-format card number
            const cardInput = document.querySelector('input[name="card_number"]');
            if (cardInput) {
                cardInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
                    e.target.value = value;
                });
            }
            
            // Auto-format expiration date
            const expInput = document.querySelector('input[name="card_exp_date"]');
            if (expInput) {
                expInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    if (value.length >= 2) {
                        value = value.substring(0,2) + '/' + value.substring(2,4);
                    }
                    e.target.value = value;
                });
            }
        });
    </script>
</body>
</html> 