<?php
$title = 'Mass Garage Doors Expert - Professional Garage Door Services';
ob_start();
?>

<!-- Hero Section -->
<div class="hero-section">
    <div class="container">
        <div class="row align-items-center min-vh-75">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold text-white mb-4">
                    Professional Garage Door Services in Massachusetts
                </h1>
                <p class="lead text-white mb-4">
                    Expert installation, repair, and maintenance services. Licensed, insured, and available 24/7 for emergency service.
                </p>
                <div class="d-flex gap-3 flex-wrap">
                    <a href="/checkout/step1" class="btn btn-primary btn-lg">
                        <i class="fas fa-calendar-check me-2"></i>
                        Schedule Free Consultation
                    </a>
                    <a href="tel:+15085554667" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-phone me-2"></i>
                        Call (888) 989-8758
                    </a>
                </div>
            </div>
            <div class="col-lg-6 text-center">
                <div class="hero-image">
                    <i class="fas fa-home fa-10x text-white opacity-75"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Services Section -->
<div class="services-section py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold" style="color: var(--primary-black);">Our Services</h2>
            <p class="lead text-muted">Comprehensive garage door solutions for residential and commercial properties</p>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="service-card text-center h-100">
                    <div class="service-icon">
                        <i class="fas fa-tools fa-3x mb-3" style="color: var(--primary-yellow);"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Repair Services</h4>
                    <p class="text-muted">Expert repair for broken springs, cables, openers, and more. Same-day service available.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="service-card text-center h-100">
                    <div class="service-icon">
                        <i class="fas fa-plus-circle fa-3x mb-3" style="color: var(--primary-yellow);"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Installation</h4>
                    <p class="text-muted">Professional installation of new garage doors and openers. Wide selection of styles and brands.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="service-card text-center h-100">
                    <div class="service-icon">
                        <i class="fas fa-cog fa-3x mb-3" style="color: var(--primary-yellow);"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Maintenance</h4>
                    <p class="text-muted">Regular maintenance to keep your garage door running smoothly and extend its lifespan.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="service-card text-center h-100">
                    <div class="service-icon">
                        <i class="fas fa-clock fa-3x mb-3" style="color: var(--primary-yellow);"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Emergency Service</h4>
                    <p class="text-muted">24/7 emergency service for urgent repairs. We're here when you need us most.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Why Choose Us Section -->
<div class="why-choose-section py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold" style="color: var(--primary-black);">Why Choose Mass Garage Doors Expert?</h2>
            <p class="lead text-muted">Your trusted local garage door professionals</p>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-4">
                <div class="feature-card d-flex">
                    <div class="feature-icon me-3">
                        <i class="fas fa-award fa-2x" style="color: var(--primary-yellow);"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold">Licensed & Insured</h5>
                        <p class="text-muted mb-0">Fully licensed and insured professionals you can trust.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="feature-card d-flex">
                    <div class="feature-icon me-3">
                        <i class="fas fa-clock fa-2x" style="color: var(--primary-yellow);"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold">Same-Day Service</h5>
                        <p class="text-muted mb-0">Fast response times with same-day service available.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="feature-card d-flex">
                    <div class="feature-icon me-3">
                        <i class="fas fa-thumbs-up fa-2x" style="color: var(--primary-yellow);"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold">100% Satisfaction</h5>
                        <p class="text-muted mb-0">We guarantee your complete satisfaction with our work.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="feature-card d-flex">
                    <div class="feature-icon me-3">
                        <i class="fas fa-map-marker-alt fa-2x" style="color: var(--primary-yellow);"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold">Local Experts</h5>
                        <p class="text-muted mb-0">Serving Massachusetts with local expertise.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="feature-card d-flex">
                    <div class="feature-icon me-3">
                        <i class="fas fa-dollar-sign fa-2x" style="color: var(--primary-yellow);"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold">Fair Pricing</h5>
                        <p class="text-muted mb-0">Competitive rates with no hidden fees.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="feature-card d-flex">
                    <div class="feature-icon me-3">
                        <i class="fas fa-shield-alt fa-2x" style="color: var(--primary-yellow);"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold">Quality Parts</h5>
                        <p class="text-muted mb-0">Only the highest quality parts and materials.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- CTA Section -->
<div class="cta-section py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h2 class="display-5 fw-bold text-white mb-4">
                    Ready to Get Started?
                </h2>
                <p class="lead text-white mb-4">
                    Schedule your free consultation today and get a no-obligation quote for your garage door needs.
                </p>
                <div class="d-flex gap-3 justify-content-center flex-wrap">
                    <a href="/checkout/step1" class="btn btn-light btn-lg">
                        <i class="fas fa-calendar-check me-2"></i>
                        Schedule Free Consultation
                    </a>
                    <a href="tel:+15085554667" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-phone me-2"></i>
                        Call Now: (508) 555-DOOR
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.hero-section {
    background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.5)), url('https://images.pexels.com/photos/186077/pexels-photo-186077.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop') center/cover;
    min-height: 80vh;
    display: flex;
    align-items: center;
    position: relative;
}

.hero-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, rgba(0, 0, 0, 0.6) 0%, rgba(0, 0, 0, 0.4) 100%);
    z-index: 1;
}

.hero-section .container {
    position: relative;
    z-index: 2;
}

.min-vh-75 {
    min-height: 75vh;
}

.services-section {
    background: white;
}

.service-card {
    padding: 2rem 1rem;
    border-radius: 12px;
    background: white;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    transition: transform 0.3s ease;
}

.service-card:hover {
    transform: translateY(-5px);
}

.feature-card {
    padding: 1rem 0;
}

.cta-section {
    background: var(--primary-black);
}

.hero-image {
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
}

@media (max-width: 768px) {
    .display-4 {
        font-size: 2.5rem;
    }
    
    .display-5 {
        font-size: 2rem;
    }
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/layouts/main.php';
?> 