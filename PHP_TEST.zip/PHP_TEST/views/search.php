<?php
$title = 'Search Results - Mass Garage Doors Expert';
ob_start();
?>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="search-results-header text-center mb-5">
                <h1 class="display-5 fw-bold" style="color: var(--primary-black);">
                    <i class="fas fa-search me-3" style="color: var(--primary-yellow);"></i>
                    Search Results
                </h1>
                <?php if (!empty($query)): ?>
                    <p class="lead text-muted">
                        Results for: <strong style="color: var(--primary-black);">"<?= htmlspecialchars($query) ?>"</strong>
                    </p>
                <?php else: ?>
                    <p class="lead text-muted">Please enter a search term to find services, repairs, and more.</p>
                <?php endif; ?>
            </div>

            <!-- Search Form -->
            <div class="search-page-form mb-5">
                <form action="/search" method="GET" class="d-flex gap-2">
                    <input type="text" 
                           class="form-control" 
                           name="q" 
                           value="<?= htmlspecialchars($query) ?>"
                           placeholder="Search for garage door services, repairs..."
                           style="border: 2px solid var(--primary-yellow); border-radius: 8px; padding: 0.75rem 1.25rem;">
                    <button type="submit" 
                            class="btn btn-primary" 
                            style="border-radius: 8px; padding: 0.75rem 1.5rem;">
                        <i class="fas fa-search me-2"></i>Search
                    </button>
                </form>
            </div>

            <?php if (!empty($query)): ?>
                <!-- Search Results Content -->
                <div class="search-results">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Search functionality is coming soon!</strong> 
                        We're working on implementing comprehensive search across our services, blog posts, and resources.
                    </div>

                    <!-- Suggested Services based on common search terms -->
                    <div class="suggested-content mt-5">
                        <h3 style="color: var(--primary-black);">
                            <i class="fas fa-lightbulb me-2" style="color: var(--primary-yellow);"></i>
                            Popular Services
                        </h3>
                        <div class="row g-4 mt-3">
                            <div class="col-md-6">
                                <div class="card h-100 border-0 shadow-sm">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <i class="fas fa-tools me-2" style="color: var(--primary-yellow);"></i>
                                            Garage Door Repair
                                        </h5>
                                        <p class="card-text">Expert repair services for broken springs, cables, openers, and more. Same-day service available.</p>
                                        <a href="/checkout/step1" class="btn btn-primary">Get Free Quote</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card h-100 border-0 shadow-sm">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <i class="fas fa-plus-circle me-2" style="color: var(--primary-yellow);"></i>
                                            New Installation
                                        </h5>
                                        <p class="card-text">Professional installation of new garage doors and openers. Wide selection of styles and brands.</p>
                                        <a href="/checkout/step1" class="btn btn-primary">Schedule Installation</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card h-100 border-0 shadow-sm">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <i class="fas fa-clock me-2" style="color: var(--primary-yellow);"></i>
                                            Emergency Service
                                        </h5>
                                        <p class="card-text">24/7 emergency service for urgent repairs. We're here when you need us most.</p>
                                        <a href="tel:+15085554667" class="btn btn-primary">Call Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card h-100 border-0 shadow-sm">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <i class="fas fa-cog me-2" style="color: var(--primary-yellow);"></i>
                                            Maintenance Service
                                        </h5>
                                        <p class="card-text">Regular maintenance to keep your garage door running smoothly and extend its lifespan.</p>
                                        <a href="/checkout/step1" class="btn btn-primary">Schedule Service</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Quick Links -->
            <div class="quick-links mt-5 text-center">
                <h4 style="color: var(--primary-black);">Need Help Finding What You're Looking For?</h4>
                <div class="d-flex gap-3 justify-content-center flex-wrap mt-3">
                    <a href="/" class="btn btn-secondary">
                        <i class="fas fa-home me-2"></i>Homepage
                    </a>
                    <a href="/checkout/step1" class="btn btn-primary">
                        <i class="fas fa-calculator me-2"></i>Free Estimate
                    </a>
                    <a href="tel:+15085554667" class="btn btn-secondary">
                        <i class="fas fa-phone me-2"></i>Call Us
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/layouts/main.php';
?> 