<?php
$title = 'Checkout - Review Order';
ob_start();
?>

<div class="container">
    <div class="checkout-container">
        <!-- Progress Header -->
        <div class="progress-header">
            <h2 class="mb-0">Secure Checkout</h2>
            <div class="progress-steps">
                <div class="step completed">
                    <div class="step-number">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="step-label">Customer Info</div>
                </div>
                <div class="step completed">
                    <div class="step-number">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="step-label">Payment</div>
                </div>
                <div class="step active">
                    <div class="step-number">3</div>
                    <div class="step-label">Review</div>
                </div>
            </div>
        </div>

        <!-- Review Section -->
        <div class="form-section">
            <h3 class="mb-4">
                <i class="fas fa-clipboard-check me-2" style="color: var(--primary-yellow);"></i>
                Review Your Order
            </h3>
            
            <!-- Customer Information Summary -->
            <div class="summary-card">
                <h5>
                    <i class="fas fa-user me-2"></i>Customer Information
                    <a href="/checkout/step1" class="btn btn-sm btn-outline-primary float-end">
                        <i class="fas fa-edit me-1"></i>Edit
                    </a>
                </h5>
                <div class="row">
                    <div class="col-md-6">
                        <p class="mb-2"><strong>Name:</strong> <?= htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']) ?></p>
                        <p class="mb-2"><strong>Email:</strong> <?= htmlspecialchars($customer['email']) ?></p>
                        <p class="mb-2"><strong>Phone:</strong> <?= htmlspecialchars($customer['phone']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p class="mb-2"><strong>Address:</strong><br>
                            <?= htmlspecialchars($customer['address']) ?><br>
                            <?= htmlspecialchars($customer['city'] . ', ' . $customer['state']) ?>
                        </p>
                    </div>
                </div>
            </div>

            <!-- Payment Information Summary -->
            <div class="summary-card">
                <h5>
                    <i class="fas fa-credit-card me-2"></i>Payment Information
                    <a href="/checkout/step2" class="btn btn-sm btn-outline-primary float-end">
                        <i class="fas fa-edit me-1"></i>Edit
                    </a>
                </h5>
                <div class="row">
                    <div class="col-md-6">
                        <p class="mb-2"><strong>Card Type:</strong> 
                            <?php
                            $cardTypes = [
                                '1' => 'Visa',
                                '2' => 'MasterCard', 
                                '3' => 'American Express',
                                '4' => 'Discover'
                            ];
                            echo htmlspecialchars($cardTypes[$payment['card_type']] ?? 'Unknown');
                            ?>
                        </p>
                        <p class="mb-2"><strong>Card Number:</strong> **** **** **** <?= htmlspecialchars(substr($payment['card_number'], -4)) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p class="mb-2"><strong>Expiration:</strong> <?= htmlspecialchars($payment['card_exp_date']) ?></p>
                    </div>
                </div>
            </div>

            <!-- Order Summary -->
            <div class="summary-card">
                <h5>
                    <i class="fas fa-shopping-cart me-2"></i>Service Summary
                </h5>
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1"><strong>Garage Door Service Consultation</strong></p>
                        <small class="text-muted">Professional assessment and quote</small>
                    </div>
                    <div class="text-end">
                        <span class="h5 text-success mb-0">FREE</span>
                    </div>
                </div>
                <hr>
                <div class="d-flex justify-content-between align-items-center">
                    <strong>Total Amount:</strong>
                    <span class="h4 text-success mb-0">$0.00</span>
                </div>
                <small class="text-muted">* No payment will be charged. This is for consultation scheduling only.</small>
            </div>

            <!-- Terms and Conditions -->
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                <strong>Important:</strong> By completing this form, you agree to receive a consultation call from our team 
                within 24 hours. No payment is required at this time. Our expert will provide a free assessment 
                and quote for your garage door needs.
            </div>

            <form method="POST" action="/checkout/step3/process">
                <div class="form-check mb-4">
                    <input class="form-check-input" type="checkbox" id="terms" name="terms" required>
                    <label class="form-check-label" for="terms">
                        I agree to the <a href="#" target="_blank">Terms of Service</a> and <a href="#" target="_blank">Privacy Policy</a> *
                    </label>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="/checkout/step2" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Payment
                    </a>
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-check me-2"></i>Complete Order
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="text-center">
                <p class="text-muted">
                    <i class="fas fa-phone me-2"></i>
                    Questions? Call us at (508) 555-DOOR for immediate assistance
                </p>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/main.php';
?> 