<?php
$title = 'Order Complete - Thank You!';
ob_start();
?>

<div class="container">
    <div class="checkout-container">
        <!-- Success Header -->
        <div class="progress-header text-center">
            <div class="mb-3">
                <i class="fas fa-check-circle fa-4x text-success"></i>
            </div>
            <h2 class="mb-2">Order Complete!</h2>
            <p class="mb-0">Thank you for choosing Mass Garage Doors Expert</p>
        </div>

        <!-- Success Content -->
        <div class="form-section text-center">
            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    <?= htmlspecialchars($success) ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <div class="mb-4">
                <h3 class="mb-3" style="color: var(--primary-black);">
                    <i class="fas fa-calendar-check me-2" style="color: var(--primary-yellow);"></i>
                    What Happens Next?
                </h3>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="card h-100 border-0 shadow-sm">
                            <div class="card-body text-center">
                                <i class="fas fa-phone-alt fa-2x mb-3" style="color: var(--primary-yellow);"></i>
                                <h5>We'll Call You</h5>
                                <p class="text-muted">Our team will contact you within 24 hours to schedule your consultation.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card h-100 border-0 shadow-sm">
                            <div class="card-body text-center">
                                <i class="fas fa-tools fa-2x mb-3" style="color: var(--primary-yellow);"></i>
                                <h5>Professional Assessment</h5>
                                <p class="text-muted">Our expert will assess your garage door needs and provide recommendations.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card h-100 border-0 shadow-sm">
                            <div class="card-body text-center">
                                <i class="fas fa-file-invoice-dollar fa-2x mb-3" style="color: var(--primary-yellow);"></i>
                                <h5>Free Quote</h5>
                                <p class="text-muted">Receive a detailed, no-obligation quote for your garage door service.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if (!empty($customer_id) && !empty($payment_id)): ?>
                <div class="alert alert-info mb-4">
                    <h5><i class="fas fa-receipt me-2"></i>Order Reference</h5>
                    <p class="mb-1"><strong>Customer ID:</strong> #<?= htmlspecialchars($customer_id) ?></p>
                    <p class="mb-0"><strong>Payment Reference:</strong> #<?= htmlspecialchars($payment_id) ?></p>
                    <small class="text-muted">Please save these numbers for your records</small>
                </div>
            <?php endif; ?>

            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card border-primary">
                        <div class="card-header bg-primary text-white text-center">
                            <h5 class="mb-0">
                                <i class="fas fa-headset me-2"></i>
                                Need Immediate Assistance?
                            </h5>
                        </div>
                        <div class="card-body text-center">
                            <p class="card-text mb-3">
                                For urgent garage door emergencies or questions about your consultation:
                            </p>
                            <div class="d-flex justify-content-center gap-3 flex-wrap">
                                <a href="tel:+15085554667" class="btn btn-primary">
                                    <i class="fas fa-phone me-2"></i>
                                    Call (508) 555-DOOR
                                </a>
                                <a href="mailto:info@massgaragedoors.com" class="btn btn-outline-primary">
                                    <i class="fas fa-envelope me-2"></i>
                                    Email Us
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-4">
                <a href="/" class="btn btn-secondary btn-lg">
                    <i class="fas fa-home me-2"></i>
                    Return to Homepage
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-10 mx-auto">
            <div class="text-center">
                <h4 class="mb-3" style="color: var(--primary-black);">Why Choose Mass Garage Doors Expert?</h4>
                <div class="row">
                    <div class="col-md-3 col-6 mb-3">
                        <i class="fas fa-award fa-2x mb-2" style="color: var(--primary-yellow);"></i>
                        <p class="small"><strong>Licensed & Insured</strong><br>Fully certified professionals</p>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <i class="fas fa-clock fa-2x mb-2" style="color: var(--primary-yellow);"></i>
                        <p class="small"><strong>24/7 Emergency</strong><br>Available when you need us</p>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <i class="fas fa-thumbs-up fa-2x mb-2" style="color: var(--primary-yellow);"></i>
                        <p class="small"><strong>Satisfaction Guaranteed</strong><br>100% customer satisfaction</p>
                    </div>
                    <div class="col-md-3 col-6 mb-3">
                        <i class="fas fa-map-marker fa-2x mb-2" style="color: var(--primary-yellow);"></i>
                        <p class="small"><strong>Local Experts</strong><br>Serving Massachusetts</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/main.php';
?> 