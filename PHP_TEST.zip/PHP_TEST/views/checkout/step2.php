<?php
$title = 'Checkout - Payment Information';
ob_start();
?>

<div class="container">
    <div class="checkout-container">
        <!-- Progress Header -->
        <div class="progress-header">
            <h2 class="mb-0">Secure Checkout</h2>
            <div class="progress-steps">
                <div class="step completed">
                    <div class="step-number">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="step-label">Customer Info</div>
                </div>
                <div class="step active">
                    <div class="step-number">2</div>
                    <div class="step-label">Payment</div>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-label">Review</div>
                </div>
            </div>
        </div>

        <!-- Form Section -->
        <div class="form-section">
            <h3 class="mb-4">
                <i class="fas fa-credit-card me-2" style="color: var(--primary-yellow);"></i>
                Payment Information
            </h3>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Please correct the following errors:
                    <ul class="mb-0 mt-2">
                        <?php foreach ($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="/checkout/step2/process" novalidate>
                <div class="mb-3">
                    <label for="card_type" class="form-label">
                        <i class="fas fa-credit-card me-1"></i>Card Type *
                    </label>
                    <select class="form-control <?= isset($errors['card_type']) ? 'is-invalid' : '' ?>" 
                            id="card_type" 
                            name="card_type" 
                            required>
                        <option value="">Select Card Type</option>
                        <option value="1" <?= ($payment['card_type'] ?? '') == '1' ? 'selected' : '' ?>>Visa</option>
                        <option value="2" <?= ($payment['card_type'] ?? '') == '2' ? 'selected' : '' ?>>MasterCard</option>
                        <option value="3" <?= ($payment['card_type'] ?? '') == '3' ? 'selected' : '' ?>>American Express</option>
                        <option value="4" <?= ($payment['card_type'] ?? '') == '4' ? 'selected' : '' ?>>Discover</option>
                    </select>
                    <?php if (isset($errors['card_type'])): ?>
                        <div class="invalid-feedback"><?= htmlspecialchars($errors['card_type']) ?></div>
                    <?php endif; ?>
                </div>

                <div class="mb-3">
                    <label for="card_number" class="form-label">
                        <i class="fas fa-hashtag me-1"></i>Card Number *
                    </label>
                    <input type="text" 
                           class="form-control <?= isset($errors['card_number']) ? 'is-invalid' : '' ?>" 
                           id="card_number" 
                           name="card_number" 
                           value="<?= htmlspecialchars($payment['card_number'] ?? '') ?>"
                           placeholder="1234 5678 9012 3456"
                           maxlength="23"
                           autocomplete="cc-number"
                           required>
                    <?php if (isset($errors['card_number'])): ?>
                        <div class="invalid-feedback"><?= htmlspecialchars($errors['card_number']) ?></div>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="card_exp_date" class="form-label">
                            <i class="fas fa-calendar me-1"></i>Expiration Date *
                        </label>
                        <input type="text" 
                               class="form-control <?= isset($errors['card_exp_date']) ? 'is-invalid' : '' ?>" 
                               id="card_exp_date" 
                               name="card_exp_date" 
                               value="<?= htmlspecialchars($payment['card_exp_date'] ?? '') ?>"
                               placeholder="MM/YY"
                               maxlength="5"
                               autocomplete="cc-exp"
                               required>
                        <?php if (isset($errors['card_exp_date'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['card_exp_date']) ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="cvv" class="form-label">
                            <i class="fas fa-lock me-1"></i>CVV Code *
                        </label>
                        <input type="text" 
                               class="form-control <?= isset($errors['cvv']) ? 'is-invalid' : '' ?>" 
                               id="cvv" 
                               name="cvv" 
                               value="<?= htmlspecialchars($payment['cvv'] ?? '') ?>"
                               placeholder="123"
                               maxlength="4"
                               autocomplete="cc-csc"
                               required>
                        <?php if (isset($errors['cvv'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['cvv']) ?></div>
                        <?php endif; ?>
                        <div class="form-text">
                            <small><i class="fas fa-info-circle me-1"></i>3-4 digit security code on the back of your card</small>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="/checkout/step1" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Customer Info
                    </a>
                    <button type="submit" class="btn btn-primary">
                        Review Order <i class="fas fa-arrow-right ms-2"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="text-center">
                <div class="d-flex justify-content-center gap-3 mb-3">
                    <i class="fab fa-cc-visa fa-2x" style="color: var(--primary-yellow);"></i>
                    <i class="fab fa-cc-mastercard fa-2x" style="color: var(--primary-yellow);"></i>
                    <i class="fab fa-cc-amex fa-2x" style="color: var(--primary-yellow);"></i>
                    <i class="fab fa-cc-discover fa-2x" style="color: var(--primary-yellow);"></i>
                </div>
                <p class="text-muted">
                    <i class="fas fa-shield-alt me-2"></i>
                    Your payment information is protected with industry-standard encryption
                </p>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/main.php';
?> 