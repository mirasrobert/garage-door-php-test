<?php
$title = 'Checkout - Customer Information';
ob_start();
?>

<div class="container">
    <div class="checkout-container">
        <!-- Progress Header -->
        <div class="progress-header">
            <h2 class="mb-0">Secure Checkout</h2>
            <div class="progress-steps">
                <div class="step active">
                    <div class="step-number">1</div>
                    <div class="step-label">Customer Info</div>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <div class="step-label">Payment</div>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-label">Review</div>
                </div>
            </div>
        </div>

        <!-- Form Section -->
        <div class="form-section">
            <h3 class="mb-4">
                <i class="fas fa-user me-2" style="color: var(--primary-yellow);"></i>
                Customer Information
            </h3>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Please correct the following errors:
                    <ul class="mb-0 mt-2">
                        <?php foreach ($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="/checkout/step1/process" novalidate>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="first_name" class="form-label">
                            <i class="fas fa-user me-1"></i>First Name *
                        </label>
                        <input type="text" 
                               class="form-control <?= isset($errors['first_name']) ? 'is-invalid' : '' ?>" 
                               id="first_name" 
                               name="first_name" 
                               value="<?= htmlspecialchars($customer['first_name'] ?? '') ?>"
                               required>
                        <?php if (isset($errors['first_name'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['first_name']) ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="last_name" class="form-label">
                            <i class="fas fa-user me-1"></i>Last Name *
                        </label>
                        <input type="text" 
                               class="form-control <?= isset($errors['last_name']) ? 'is-invalid' : '' ?>" 
                               id="last_name" 
                               name="last_name" 
                               value="<?= htmlspecialchars($customer['last_name'] ?? '') ?>"
                               required>
                        <?php if (isset($errors['last_name'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['last_name']) ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="address" class="form-label">
                        <i class="fas fa-home me-1"></i>Street Address *
                    </label>
                    <input type="text" 
                           class="form-control <?= isset($errors['address']) ? 'is-invalid' : '' ?>" 
                           id="address" 
                           name="address" 
                           value="<?= htmlspecialchars($customer['address'] ?? '') ?>"
                           placeholder="123 Main Street"
                           required>
                    <?php if (isset($errors['address'])): ?>
                        <div class="invalid-feedback"><?= htmlspecialchars($errors['address']) ?></div>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="city" class="form-label">
                            <i class="fas fa-city me-1"></i>City *
                        </label>
                        <input type="text" 
                               class="form-control <?= isset($errors['city']) ? 'is-invalid' : '' ?>" 
                               id="city" 
                               name="city" 
                               value="<?= htmlspecialchars($customer['city'] ?? '') ?>"
                               required>
                        <?php if (isset($errors['city'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['city']) ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="state" class="form-label">
                            <i class="fas fa-flag me-1"></i>State *
                        </label>
                        <input type="text" 
                               class="form-control <?= isset($errors['state']) ? 'is-invalid' : '' ?>" 
                               id="state" 
                               name="state" 
                               value="<?= htmlspecialchars($customer['state'] ?? '') ?>"
                               placeholder="MA"
                               maxlength="2"
                               style="text-transform: uppercase;"
                               required>
                        <?php if (isset($errors['state'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['state']) ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="phone" class="form-label">
                            <i class="fas fa-phone me-1"></i>Phone Number *
                        </label>
                        <input type="tel" 
                               class="form-control <?= isset($errors['phone']) ? 'is-invalid' : '' ?>" 
                               id="phone" 
                               name="phone" 
                               value="<?= htmlspecialchars($customer['phone'] ?? '') ?>"
                               placeholder="(555) 123-4567"
                               required>
                        <?php if (isset($errors['phone'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['phone']) ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">
                            <i class="fas fa-envelope me-1"></i>Email Address *
                        </label>
                        <input type="email" 
                               class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" 
                               id="email" 
                               name="email" 
                               value="<?= htmlspecialchars($customer['email'] ?? '') ?>"
                               placeholder="john@example.com"
                               required>
                        <?php if (isset($errors['email'])): ?>
                            <div class="invalid-feedback"><?= htmlspecialchars($errors['email']) ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="/" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Home
                    </a>
                    <button type="submit" class="btn btn-primary">
                        Continue to Payment <i class="fas fa-arrow-right ms-2"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="text-center">
                <p class="text-muted">
                    <i class="fas fa-shield-alt me-2"></i>
                    Your information is protected with 256-bit SSL encryption
                </p>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/main.php';
?> 