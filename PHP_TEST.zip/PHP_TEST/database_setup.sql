-- Database setup for Mass Garage Doors Expert Checkout System
-- Run these commands to create the required database and tables

-- Create database (uncomment if needed)
-- CREATE DATABASE my_db;
-- USE my_db;

-- Create customer_details table
CREATE TABLE IF NOT EXISTS customer_details (
  id mediumint(10) NOT NULL AUTO_INCREMENT,
  first_name char(25) NOT NULL,
  last_name char(25) NOT NULL,
  address char(100) NOT NULL,
  city char(50) NOT NULL,
  state char(2) NOT NULL,
  phone int(10) NOT NULL,
  email varchar(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

-- Create payment_details table
CREATE TABLE IF NOT EXISTS payment_details (
  id mediumint(10) NOT NULL AUTO_INCREMENT,
  card_type tinyint(1) NOT NULL,
  card_number varchar(50) NOT NULL,
  card_exp_date varchar(50) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

-- Create posts table (for existing functionality)
CREATE TABLE IF NOT EXISTS posts (
  id mediumint(10) NOT NULL AUTO_INCREMENT,
  title varchar(255) NOT NULL,
  content text NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

-- Insert sample posts (for existing functionality)
INSERT INTO posts (title, content) VALUES 
('Welcome to Mass Garage Doors Expert', 'Professional garage door services in Massachusetts.'),
('Emergency Garage Door Repair', 'Available 24/7 for all your urgent garage door needs.'),
('New Garage Door Installation', 'Expert installation of residential and commercial garage doors.');

-- Card type reference:
-- 1 = Visa
-- 2 = MasterCard
-- 3 = American Express  
-- 4 = Discover 